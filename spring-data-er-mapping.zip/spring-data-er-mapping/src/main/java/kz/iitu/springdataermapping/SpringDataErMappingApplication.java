package kz.iitu.springdataermapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataErMappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataErMappingApplication.class, args);
	}

}
