package kz.iitu.springsecurityexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
