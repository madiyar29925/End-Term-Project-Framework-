package kz.iitu.springdataermapping;

import kz.iitu.springdataermapping.config.SpringConfig;
import kz.iitu.springdataermapping.entity.Address;
import kz.iitu.springdataermapping.entity.User;
import kz.iitu.springdataermapping.repository.BookRepository;
import kz.iitu.springdataermapping.repository.StudentRepository;
import kz.iitu.springdataermapping.repository.UserRepository;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

    public static void main(String[] args) {
//        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
//
//        UserRepository userRepository = context.getBean("userRepository", UserRepository.class);
//        System.out.println("userRepository.findAll() = " + userRepository.findAll());
//
//        User user = new User();
//        user.setName("New user");
//        user.setAge(30);
//
//        Address address = new Address();
////        address.setId(1L);
//        address.setHouseNo(90);
//        address.setStreet("Zhandosov St.");
//
//        user.setAddress(address);
//
//        userRepository.saveAndFlush(user);

//        BookRepository bookRepository = context.getBean("bookRepository", BookRepository.class);
//        System.out.println("bookRepository.findAll() = " + bookRepository.findAll());

//        StudentRepository studentRepository = context.getBean("studentRepository", StudentRepository.class);
//        System.out.println("studentRepository.findAll() = " + studentRepository.findAll());
    }
}
